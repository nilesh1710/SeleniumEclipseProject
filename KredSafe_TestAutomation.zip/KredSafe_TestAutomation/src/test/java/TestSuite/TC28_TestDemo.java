package TestSuite;

import org.testng.annotations.BeforeClass;

import com.KredSafe.TestBase.TestBase;

public class TC28_TestDemo extends TestBase {
	@BeforeClass
	public static void startTest() {

		test = extent.startTest("TC25_VerifyProfileflow");

	}	

}
