package TestSuite;

public class Changepasswords {

}
